#import <Foundation/Foundation.h>

@interface statesBaseClass : NSObject {

    NSString *name;
    NSNumber *statesBaseClassId;

}

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSNumber *statesBaseClassId;

+ (statesBaseClass *)instanceFromDictionary:(NSDictionary *)aDictionary;
- (void)setAttributesFromDictionary:(NSDictionary *)aDictionary;

@end
