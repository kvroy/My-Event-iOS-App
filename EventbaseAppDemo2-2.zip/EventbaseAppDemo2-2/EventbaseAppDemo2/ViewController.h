//
//  ViewController.h
//  EventbaseAppDemo2
//
//  Created by Harsh Bhatnagar on 29/03/17.
//  Copyright © 2017 harshbhatnagariosdeveloper. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property(nonatomic, retain)NSString* eventTypeSelected;
@end

