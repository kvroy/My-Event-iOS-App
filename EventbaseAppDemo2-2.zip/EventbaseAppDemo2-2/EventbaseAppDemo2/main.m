//
//  main.m
//  EventbaseAppDemo2
//
//  Created by Harsh Bhatnagar on 29/03/17.
//  Copyright © 2017 harshbhatnagariosdeveloper. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
