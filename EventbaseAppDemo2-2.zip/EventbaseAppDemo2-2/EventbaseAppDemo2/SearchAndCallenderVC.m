//
//  SearchAndCallenderVC.m
//  EventbaseAppDemo2
//
//  Created by Harsh Bhatnagar on 30/03/17.
//  Copyright © 2017 harshbhatnagariosdeveloper. All rights reserved.
//

#import <EventKit/EventKit.h>
#import "SearchAndCallenderVC.h"

@interface SearchAndCallenderVC ()
@property (strong, nonatomic) IBOutlet UISearchBar *EventSearchBar;
@property (strong, nonatomic) IBOutlet UITableView *eventsTableView;
@property (strong, nonatomic) IBOutlet UICollectionView *calanderCollectionView;




@end

@implementation SearchAndCallenderVC

- (void)viewDidLoad {
//    self.EventSearchBar.hidden = YES;
//    self.eventsTableView.hidden= YES;
//    self.calanderCollectionView.hidden = YES;
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self cal];
    
    
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)cal{
  
    
}
 



@end
