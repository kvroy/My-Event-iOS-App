//
//  PaymantVC.m
//  EventbaseAppDemo2
//
//  Created by Harsh Bhatnagar on 30/03/17.
//  Copyright © 2017 harshbhatnagariosdeveloper. All rights reserved.
//

#import "PaymantVC.h"
#import "DataBaseClass.h"
@interface PaymantVC ()
@property (strong, nonatomic) IBOutlet UIWebView *paymantWebView;
@property (strong, nonatomic) IBOutlet UILabel *totalcostLable;

@end

@implementation PaymantVC

- (void)viewDidLoad {
    [super viewDidLoad];
    ///
   
   
    NSString *url=[NSString stringWithFormat:@"http:/google.com"];
    NSURLRequest *request=[NSURLRequest requestWithURL:[NSURL URLWithString:url]];
     [self.paymantWebView loadRequest:request];
    ////
      DataBaseClass *dbc = [[DataBaseClass alloc]init];
    [dbc paymantVC];
    self.totalPay = [[NSUserDefaults standardUserDefaults] objectForKey:@"totalPay"];
    if(self.totalPay == nil){
    self.totalPay = @"100";
    }
   self.totalcostLable.text = [@"Your Total Payment Rs." stringByAppendingString:self.totalPay];
    // Do any additional setup after loading the view.
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)doneBtn:(id)sender {
   
       NSString *aValue = [[NSUserDefaults standardUserDefaults] objectForKey:@"firstName"];
     NSLog(@"NSUserDefaults array = %@",aValue);
}

@end
/*
 #import <LocalAuthentication/LocalAuthentication.h>
 #import <CoreLocation/CoreLocation.h>
 #import "ECSServiceClass.h"

 
 
 ECSServiceClass * class = [[ECSServiceClass alloc]init];
 [class setServiceMethod:GET];
 [class setServiceURL:[NSString stringWithFormat:@"http://s171227279.onlinehome.us/ecom/labnmeds/public/index.php/api/v1/city/getAllCity"]];
 
 [class addHeader:@"fgfid$rakesh$8df638f$7fsdsfasdfsf$bcas90dudf$gsrivastava" forKey:@"X-APPKEY"];
 [class addHeader:@"864a6a9ae4fba992" forKey:@"X-DEVICE-ID"];
 [class setCallback:@selector(callBackServiceGetYogaVideos:)];
 [class setController:self];
 [class runService];
 
 
 -(void)callBackServiceGetYogaVideos:(ECSResponse *)response
 {
 NSLog(@"response %@",response.stringValue);
 NSError *error;
 NSMutableArray *countriesArray=[[NSMutableArray alloc]init];
 NSDictionary *baseDic = [NSJSONSerialization JSONObjectWithData:response.data options:0 error:&error];
 MyClassObject *instance = [[MyClassObject alloc] init];
 for (NSDictionary *status in response.extraDictionary) {
 instance.code = [status object$ForKey:@"code"];
 instance.data = [status objectForKey:@"data"];
 instance.developerMsg = [status objectForKey:@"developerMsg"];
 instance.message = [status objectForKey:@"message"];
 [countriesArray addObject:instance];
 }
 NSLog(@"countriesArray %@",countriesArray);
 }

*/