//
//  EventPlaceDetailsVC.m
//  EventbaseAppDemo2
//
//  Created by Harsh Bhatnagar on 30/03/17.
//  Copyright © 2017 harshbhatnagariosdeveloper. All rights reserved.
//
#define LABEL_TAG 100001
#define xImage 0
#define yImage 0
#define imageWidth 10
#define imageHeight 20
#define xTitle 0
#define yTitle 80
#define titleWidth 110
#define titleHeight 15
#import "PaymantVC.h"
#import "RegistrationVC.h"
#import "ServicesVC.h"
#import "EventPlaceDetailsVC.h"
#import "DataBaseClass.h"

@interface EventPlaceDetailsVC ()<UICollectionViewDataSource, UICollectionViewDelegate,UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegateFlowLayout>
@property (strong, nonatomic) IBOutlet UICollectionView *collectionViewHotalDetails;
@property (strong, nonatomic) IBOutlet UITableView *otherDealsTableViewOutlet;
@property (strong, nonatomic) IBOutlet UILabel *hotalCostLable;
@property (strong, nonatomic) IBOutlet UILabel *hotalOfferLable;

@property (nonatomic,strong)NSMutableArray * hotalsName;
@property (nonatomic,strong)NSMutableArray * hotalsNameForCollectionView;
@property (nonatomic,strong)NSMutableArray * hotalsImage;
@property (nonatomic,strong)NSMutableArray * hotalsImage1;
@property (nonatomic,strong)NSMutableArray * hotalsImage2;
@property (nonatomic,strong)NSMutableArray * hotalsImage3;
@property (nonatomic,strong)NSMutableArray * hotalsImage4;
@property (nonatomic,strong)NSMutableArray * hotalsImage5;
@property (nonatomic,strong)NSMutableArray * hotalsImage6;

@property NSInteger tableSelection;
-(void)viewDidLoadDefault;
@end

@implementation EventPlaceDetailsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self viewDidLoadDefault];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)bookNowBtn:(id)sender {
  
    NSString *firstName = [[NSUserDefaults standardUserDefaults] objectForKey:@"firstName"];
    if (firstName != nil){
    PaymantVC *NVC = [self.storyboard instantiateViewControllerWithIdentifier:@"paymantVC"];
    [self presentViewController:NVC animated:YES completion:nil];
    }else{
        RegistrationVC *NVC = [self.storyboard instantiateViewControllerWithIdentifier:@"registrationVC"];
        [self presentViewController:NVC animated:YES completion:nil];
    }
    
}
- (IBAction)offerDetails:(id)sender {
    ServicesVC *NVC = [self.storyboard instantiateViewControllerWithIdentifier:@"servicesVC"];
    NVC.hotalNumber = self.tableSelection;
    [self presentViewController:NVC animated:YES completion:nil];
}
////

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.hotalsName.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
  
    cell.backgroundColor =[UIColor whiteColor];
    self.collectionViewHotalDetails.backgroundColor=[UIColor whiteColor];
    ///
    UILabel *label = (UILabel*)[cell.contentView viewWithTag:LABEL_TAG];
    
    if (!label) {
        label = [[UILabel alloc] initWithFrame:CGRectMake(5.0, 90.0,90.0, 21.0)];
        label.textColor = [UIColor redColor];
        label.backgroundColor = [UIColor clearColor];
        label.font = [UIFont boldSystemFontOfSize:12];
        label.textColor = [UIColor colorWithRed:46.0/255.0 green:63.0/255.0 blue:81.0/255.0 alpha:1.0];
        label.tag = LABEL_TAG;
        [cell.contentView addSubview:label];
    }
    
    label.text = [NSString stringWithFormat:@"%@",[self.hotalsNameForCollectionView objectAtIndex:indexPath.row]];

    if (self.tableSelection == 0){
    cell.backgroundView = [[UIImageView alloc]initWithImage:[self.hotalsImage1 objectAtIndex:indexPath.row]];
    }else if (self.tableSelection == 1){
        cell.backgroundView = [[UIImageView alloc]initWithImage:[self.hotalsImage2 objectAtIndex:indexPath.row]];
    }else if (self.tableSelection == 2){
        cell.backgroundView = [[UIImageView alloc]initWithImage:[self.hotalsImage3 objectAtIndex:indexPath.row]];
    }else if (self.tableSelection == 3){
        cell.backgroundView = [[UIImageView alloc]initWithImage:[self.hotalsImage4 objectAtIndex:indexPath.row]];
    }else if (self.tableSelection == 4){
        cell.backgroundView = [[UIImageView alloc]initWithImage:[self.hotalsImage5 objectAtIndex:indexPath.row]];
    }else if (self.tableSelection == 5){
        cell.backgroundView = [[UIImageView alloc]initWithImage:[self.hotalsImage6 objectAtIndex:indexPath.row]];
    }else{
    cell.backgroundView = [[UIImageView alloc]initWithImage:[self.hotalsImage objectAtIndex:indexPath.row]];
    }
  
   
    
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    [self.otherDealsTableViewOutlet reloadData];
//    EventDetailsData *NVC = [self.storyboard instantiateViewControllerWithIdentifier:@"eventDetailsData"];
//    NVC.eventSelected = indexPath.row;
//    [self presentViewController:NVC animated:YES completion:nil];
//    
}
//- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
//{
//    return 1.0;
//}
//
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 30.0;
}

//- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
//{
//    return UIEdgeInsetsMake(5, 2.0, 5, 2.0);
//}
//- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
//{
//    CGSize newSize = CGSizeZero;
//    newSize.height = 100;
//    
//    CGRect screenBounds = [[UIScreen mainScreen] bounds];
//    CGSize screenSize = screenBounds.size;
//    newSize.width = screenSize.width * 0.23;
//    return newSize;
//}

////
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.hotalsName.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"SimpleTableItem";
    
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:simpleTableIdentifier];
    cell.textLabel.text = [self.hotalsName objectAtIndex:indexPath.row];
    cell.detailTextLabel.text= @"hi";
    
   // cell.imageView.image = [UIImage imageNamed:[self.hotalsImage objectAtIndex:indexPath.row]];
    cell.imageView.image = [self.hotalsImage objectAtIndex:indexPath.row];

    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    self.tableSelection = indexPath.row;
  //  NSLog(@"table %ld",(long)self.tableSelection);
    self.placeForEvent = [self.hotalsName objectAtIndex:indexPath.row];
   
    DataBaseClass *dbc = [[DataBaseClass alloc]init];
    [dbc placeForEvent:self.placeForEvent];
   
    [self.collectionViewHotalDetails reloadData];
}


////
-(void)viewDidLoadDefault{
    self.tableSelection = 0;
    self.otherDealsTableViewOutlet.delegate = self;
    self.otherDealsTableViewOutlet.dataSource = self;
    [self.otherDealsTableViewOutlet registerClass:[UITableViewCell class] forCellReuseIdentifier:@"SimpleTableItem"];
    [self.view addSubview:self.otherDealsTableViewOutlet];
    
    // Do any additional setup after loading the view.
    self.collectionViewHotalDetails.delegate = self;
    self.collectionViewHotalDetails.dataSource = self;
    [self.collectionViewHotalDetails registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cellIdentifier"];
    [self.view addSubview:self.collectionViewHotalDetails];
   // UICollectionViewFlowLayout *layout=[[UICollectionViewFlowLayout alloc] init];
    //self.collectionViewHotalDetails=[[UICollectionView alloc] initWithFrame:self.view.frame collectionViewLayout:layout];
    
    self.hotalsName=[NSMutableArray arrayWithObjects:@"hotal1",@"hotal2",@"hotal3",@"hotal4",@"hotal5",@"hotal6",nil];
    self.hotalsNameForCollectionView=[NSMutableArray arrayWithObjects:@"Main Intrance",@"Inside Hotal",@"OutSide Hotal",@"Decoration",@"Place Area",@"Parking Area",nil];
    
    
    self.hotalsImage =[[NSMutableArray alloc]init];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal1.png"]];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal2.png"]];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal3.png"]];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal4.png"]];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal5.png"]];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal6.png"]];
    
    self.hotalsImage1 =[[NSMutableArray alloc]init];
    [self.hotalsImage1  addObject:[UIImage imageNamed:@"hotal1.png"]];
    [self.hotalsImage1  addObject:[UIImage imageNamed:@"hotal1.png"]];
    [self.hotalsImage1  addObject:[UIImage imageNamed:@"hotal1.png"]];
    [self.hotalsImage1  addObject:[UIImage imageNamed:@"hotal1.png"]];
    [self.hotalsImage1  addObject:[UIImage imageNamed:@"hotal1.png"]];
    [self.hotalsImage1  addObject:[UIImage imageNamed:@"hotal1.png"]];
    self.hotalsImage2 =[[NSMutableArray alloc]init];
    [self.hotalsImage2  addObject:[UIImage imageNamed:@"hotal2.png"]];
    [self.hotalsImage2  addObject:[UIImage imageNamed:@"hotal2.png"]];
    [self.hotalsImage2  addObject:[UIImage imageNamed:@"hotal2.png"]];
    [self.hotalsImage2  addObject:[UIImage imageNamed:@"hotal2.png"]];
    [self.hotalsImage2  addObject:[UIImage imageNamed:@"hotal2.png"]];
    [self.hotalsImage2  addObject:[UIImage imageNamed:@"hotal2.png"]];
    self.hotalsImage3 =[[NSMutableArray alloc]init];
    [self.hotalsImage3  addObject:[UIImage imageNamed:@"hotal3.png"]];
    [self.hotalsImage3  addObject:[UIImage imageNamed:@"hotal3.png"]];
    [self.hotalsImage3  addObject:[UIImage imageNamed:@"hotal3.png"]];
    [self.hotalsImage3  addObject:[UIImage imageNamed:@"hotal3.png"]];
    [self.hotalsImage3  addObject:[UIImage imageNamed:@"hotal3.png"]];
    [self.hotalsImage3  addObject:[UIImage imageNamed:@"hotal3.png"]];
    self.hotalsImage4 =[[NSMutableArray alloc]init];
    [self.hotalsImage4  addObject:[UIImage imageNamed:@"hotal4.png"]];
    [self.hotalsImage4  addObject:[UIImage imageNamed:@"hotal4.png"]];
    [self.hotalsImage4  addObject:[UIImage imageNamed:@"hotal4.png"]];
    [self.hotalsImage4  addObject:[UIImage imageNamed:@"hotal4.png"]];
    [self.hotalsImage4  addObject:[UIImage imageNamed:@"hotal4.png"]];
    [self.hotalsImage4  addObject:[UIImage imageNamed:@"hotal4.png"]];
    self.hotalsImage5 =[[NSMutableArray alloc]init];
    [self.hotalsImage5  addObject:[UIImage imageNamed:@"hotal5.png"]];
    [self.hotalsImage5  addObject:[UIImage imageNamed:@"hotal5.png"]];
    [self.hotalsImage5  addObject:[UIImage imageNamed:@"hotal5.png"]];
    [self.hotalsImage5  addObject:[UIImage imageNamed:@"hotal5.png"]];
    [self.hotalsImage5  addObject:[UIImage imageNamed:@"hotal5.png"]];
    [self.hotalsImage5  addObject:[UIImage imageNamed:@"hotal5.png"]];
    self.hotalsImage6 =[[NSMutableArray alloc]init];
    [self.hotalsImage6  addObject:[UIImage imageNamed:@"hotal6.png"]];
    [self.hotalsImage6  addObject:[UIImage imageNamed:@"hotal6.png"]];
    [self.hotalsImage6  addObject:[UIImage imageNamed:@"hotal6.png"]];
    [self.hotalsImage6  addObject:[UIImage imageNamed:@"hotal6.png"]];
    [self.hotalsImage6  addObject:[UIImage imageNamed:@"hotal6.png"]];
    [self.hotalsImage6  addObject:[UIImage imageNamed:@"hotal6.png"]];
}
@end
