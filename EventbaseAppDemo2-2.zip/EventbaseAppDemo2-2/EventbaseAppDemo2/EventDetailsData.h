//
//  EventDetailsData.h
//  EventbaseAppDemo2
//
//  Created by Harsh Bhatnagar on 30/03/17.
//  Copyright © 2017 harshbhatnagariosdeveloper. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EventDetailsData : UIViewController
@property NSInteger eventSelected;


///for data base
@property(nonatomic , strong)NSString * dateOfEvent;
@property(nonatomic , strong)NSString * eventState;
@property(nonatomic , strong)NSString * eventCity;
@property(nonatomic , strong)NSString * numberOfGuest;
@property(nonatomic , strong)NSString * costPerGuest;
// dateOfEvent eventState eventCity numberOfGuest CostPerGuest
@end
