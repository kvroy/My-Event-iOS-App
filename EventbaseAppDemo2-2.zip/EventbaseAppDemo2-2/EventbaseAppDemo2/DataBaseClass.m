//
//  DataBaseClass.m
//  EventbaseAppDemo2
//
//  Created by Harsh Bhatnagar on 04/04/17.
//  Copyright © 2017 harshbhatnagariosdeveloper. All rights reserved.
//

#import "DataBaseClass.h"

@implementation DataBaseClass

-(void)dataBaseNSUserDefaults:(NSString *)firstName lastName:(NSString *)lastName mobile:(NSString *)mobile email:(NSString *)email password:(NSString *)password{
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    
    if (standardUserDefaults) {
        [standardUserDefaults setObject:firstName forKey:@"firstName"];
        [standardUserDefaults setObject:lastName forKey:@"lastName"];
        [standardUserDefaults setObject:mobile forKey:@"mobile"];
        [standardUserDefaults setObject:email forKey:@"email"];
        [standardUserDefaults setObject:password forKey:@"password"];
        [standardUserDefaults synchronize];
        self.firstName = firstName;
        self.lastName = lastName;
        self.mobile = mobile;
        self.email = email;
        self.password =password;
    }
}
//ViewController
-(void)eventTypeSelected:(NSString *)eventTypeSelected{
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    
    if (standardUserDefaults) {
        [standardUserDefaults setObject:eventTypeSelected forKey:@"eventTypeSelected"];
        self.eventTypeSelected = eventTypeSelected;
        [standardUserDefaults synchronize];
}
}
-(void)eventdetailsdata:(NSString *)dateOfEvent eventState:(NSString *)eventState eventCity:(NSString *)eventCity numberOfGuest:(NSString *)numberOfGuest costPerGuest:(NSString *)costPerGuest{
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    
    if (standardUserDefaults) {
        [standardUserDefaults setObject:dateOfEvent forKey:@"dateOfEvent"];
        [standardUserDefaults setObject:eventState forKey:@"eventState"];
        [standardUserDefaults setObject:eventCity forKey:@"eventCity"];
        [standardUserDefaults setObject:numberOfGuest forKey:@"numberOfGuest"];
        [standardUserDefaults setObject:costPerGuest forKey:@"costPerGuest"];
        self.dateOfEvent =dateOfEvent;
        self.eventState =eventState;
        self.eventCity =eventCity;
        self.numberOfGuest = numberOfGuest;
        self.costPerGuest = costPerGuest;
        [standardUserDefaults synchronize];
}
}

-(void)placeForEvent:(NSString *)placeforevent{
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    
    if (standardUserDefaults) {
        [standardUserDefaults setObject:placeforevent forKey:@"placeForEvent"];}
    self.placeForEvent = placeforevent;
}

-(void)sirvicesAry:(NSMutableArray*)sirvicesarray{
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    
    if (standardUserDefaults) {
        [standardUserDefaults setObject:sirvicesarray forKey:@"sirvicesarray"];}
    self.sirvicesArray = sirvicesarray;
}

//#import "PaymantVC.h" totalPay
-(void)paymantVC{
// Accourding to services please give user final payment value
    //default value
    
    NSString *pay= @"100";
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    
    if (standardUserDefaults) {
        [standardUserDefaults setObject:pay forKey:@"totalPay"];}
    self.totalPay = pay;
}








-(void)dealloc
{
    self.firstName = nil;
    self.lastName = nil;
    self.mobile = nil;
    self.email = nil;
    self.password = nil;
}
-(id)init
{
    self.firstName = [[NSString alloc]init];
    self.lastName = [[NSString alloc]init];
    self.mobile = [[NSString alloc]init];
    self.email = [[NSString alloc]init];
    self.password = [[NSString alloc]init];
return self;
}
@end

/*

 NSMutableDictionary *mutableDict = [[NSMutableDictionary alloc]init];'
 [mutableDict setObject:@"Value1" forKey:@"Key1"];
 [mutableDict setObject:@"Value2" forKey:@"Key2"];
 [mutableDict setObject:@"Value3" forKey:@"Key3"];

 [mutableDict removeObject:@"Value1" forKey:@"Key1"];
 
 NSArray *objectsforKey = [dict objectForKey:@"USA"];
 
*/
