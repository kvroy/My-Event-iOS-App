//
//  ServicesVC.m
//  EventbaseAppDemo2
//
//  Created by Harsh Bhatnagar on 30/03/17.
//  Copyright © 2017 harshbhatnagariosdeveloper. All rights reserved.
//
#import "RegistrationVC.h"
#import "ServicesVC.h"
#import "DataBaseClass.h"
#import "ProfileVC.h"
@interface ServicesVC ()
@property (strong, nonatomic) IBOutlet UISwitch *sirv1BtnOutlet;
@property (strong, nonatomic) IBOutlet UISwitch *sirv2BtnOutlet;
@property (strong, nonatomic) IBOutlet UISwitch *sirv3BtnOutlet;
@property (strong, nonatomic) IBOutlet UISwitch *sirv4BtnOutlet;
@property (strong, nonatomic) IBOutlet UISwitch *sirv5BtnOutlet;
@property (strong, nonatomic) IBOutlet UISwitch *sirv6BtnOutlet;

@property (strong, nonatomic) IBOutlet UILabel *sirv1Lable;
@property (strong, nonatomic) IBOutlet UILabel *sirv2Lable;
@property (strong, nonatomic) IBOutlet UILabel *sirv3Lable;
@property (strong, nonatomic) IBOutlet UILabel *sirv4Lable;
@property (strong, nonatomic) IBOutlet UILabel *sirv5Lable;
@property (strong, nonatomic) IBOutlet UILabel *sirv6Lable;
@property (strong, nonatomic) IBOutlet UIImageView *hotalImg;
@property (strong, nonatomic) IBOutlet UILabel *costingLable;
@property (strong, nonatomic) IBOutlet UILabel *offerCostingLable;


@property(nonatomic ,strong)NSMutableArray *hotalsImage;
@end

@implementation ServicesVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.sirvicesArray = [[NSMutableArray alloc]init];
    // Do any additional setup after loading the view.
    self.hotalsImage =[[NSMutableArray alloc]init];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal1.png"]];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal2.png"]];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal3.png"]];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal4.png"]];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal5.png"]];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal6.png"]];

    self.hotalImg.image=[self.hotalsImage objectAtIndex:self.hotalNumber];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)homeBtnAction:(UIButton *)sender {
}
- (IBAction)SearchBtnAction:(UIButton *)sender {
}
- (IBAction)calBtn:(UIButton *)sender {
}

- (IBAction)profileBtn:(UIButton *)sender {
    ProfileVC *NVC = [self.storyboard instantiateViewControllerWithIdentifier:@"profileVC"];
    [self presentViewController:NVC animated:YES completion:nil];
    //#import "ProfileVC.h"
}

- (IBAction)summitBtn:(id)sender {
    [self.sirvicesArray removeAllObjects];
    
    if ([_sirv1BtnOutlet isOn]){
    
            [self.sirvicesArray addObject:@"sirv1on"];
        }else{
    
            [self.sirvicesArray addObject:@"sirv1off"];
        }
    
    if ([_sirv2BtnOutlet isOn]){
    
            [self.sirvicesArray addObject:@"sirv2on"];
        }else{
    
            [self.sirvicesArray addObject:@"sirv2off"];
        }
    
    if ([_sirv3BtnOutlet isOn]){
    
            [self.sirvicesArray addObject:@"sirv3on"];
        }else{
    
            [self.sirvicesArray addObject:@"sirv3off"];
        }
    
    if ([_sirv4BtnOutlet isOn]){
    
            [self.sirvicesArray addObject:@"sirv4on"];
        }else{
    
            [self.sirvicesArray addObject:@"sirv4off"];
    }
    
    if ([_sirv5BtnOutlet isOn]){
        
                [self.sirvicesArray addObject:@"sirv5on"];
            }else{
        
                [self.sirvicesArray addObject:@"sirv5off"];
            }
    
    if ([_sirv6BtnOutlet isOn]){
    
            [self.sirvicesArray addObject:@"sirv6on"];
        }else{
    
            [self.sirvicesArray addObject:@"sirv6off"];
        }
   // check which sirvire is unabled...
    if ([self.sirvicesArray containsObject: @"sirv6off"]) // YES
    {
         NSLog(@"array %@",self.sirvicesArray);
       
        DataBaseClass *dbc = [[DataBaseClass alloc]init];
        [dbc sirvicesAry:self.sirvicesArray];
    }
  
 
    
    
}
- (IBAction)bookBtn:(id)sender {
    RegistrationVC *NVC = [self.storyboard instantiateViewControllerWithIdentifier:@"registrationVC"];
  //  NVC.hotalNumber = self.tableSelection;
    [self presentViewController:NVC animated:YES completion:nil];
}
 

@end
