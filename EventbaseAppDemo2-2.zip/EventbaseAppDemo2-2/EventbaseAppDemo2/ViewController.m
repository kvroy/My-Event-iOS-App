//
//  ViewController.m
//  EventbaseAppDemo2
//
//  Created by Harsh Bhatnagar on 29/03/17.
//  Copyright © 2017 harshbhatnagariosdeveloper. All rights reserved.
//
#define xImage 0
#define yImage 0
#define imageWidth 10
#define imageHeight 20
#define xTitle 0
#define yTitle 85
#define titleWidth 90
#define titleHeight 15
#import "SearchAndCallenderVC.h"
#import "ProfileVC.h"
#import "DataBaseClass.h"
#import "ViewController.h"
#import "EventDetailsData.h"

@interface ViewController ()<UICollectionViewDataSource, UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>
@property (strong, nonatomic) IBOutlet UICollectionView *collectionViewOutlet;
@property (strong, nonatomic) IBOutlet UIImageView *logoImage;
@property (nonatomic,strong)NSMutableArray * hotalsName;
@property (nonatomic,strong)NSMutableArray * hotalsImage;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//Logo Image
    self.logoImage.image = [UIImage imageNamed:@"logo.png"];
   // self.logoImage.image =
    
    self.collectionViewOutlet.delegate = self;
    self.collectionViewOutlet.dataSource = self;
    
    [self.collectionViewOutlet registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cellIdentifier"];
    [self.view addSubview:self.collectionViewOutlet];
  
    self.hotalsImage =[[NSMutableArray alloc]init];
    
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal1.png"]];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal2.png"]];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal3.png"]];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal4.png"]];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal5.png"]];
    [self.hotalsImage  addObject:[UIImage imageNamed:@"hotal6.png"]];
    
   self.hotalsName=[NSMutableArray arrayWithObjects:@"hotal1",@"hotal2",@"hotal3",@"hotal4",@"hotal5",@"hotal6",nil];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)homeBtnAction:(UIButton *)sender {
    EventDetailsData *eventDetailsData=[[EventDetailsData alloc]initWithNibName:@"eventDetailsData" bundle:nil];
    [self.navigationController pushViewController:eventDetailsData animated:YES];

}
- (IBAction)SearchBtnAction:(UIButton *)sender {
}
- (IBAction)calBtn:(UIButton *)sender {
    SearchAndCallenderVC *NVC = [self.storyboard instantiateViewControllerWithIdentifier:@"searchAndCallenderVC"];
    [self presentViewController:NVC animated:YES completion:nil];

    
}

- (IBAction)profileBtn:(UIButton *)sender {
    ProfileVC *NVC = [self.storyboard instantiateViewControllerWithIdentifier:@"profileVC"];
    [self presentViewController:NVC animated:YES completion:nil];
}
///

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.hotalsName.count;
    }
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    //[self.collectionViewOutlet registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
  UICollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
   // cell.frame.size.height = ;
   // cell.frame.size.width  = ;
    
    //cell.backgroundColor =[UIColor whiteColor];
   // self.collectionViewOutlet.backgroundColor=[UIColor whiteColor];
    ///
     cell.backgroundView = [[UIImageView alloc]initWithImage:[self.hotalsImage objectAtIndex:indexPath.row]];
    ///
    UILabel *testLabel = [[UILabel alloc]initWithFrame:CGRectMake(xTitle, yTitle, titleWidth, titleHeight)];
    testLabel.text = [self.hotalsName objectAtIndex:indexPath.row];
    testLabel.clipsToBounds = YES;
    testLabel.textColor = [UIColor darkGrayColor];
    testLabel.textAlignment = NSTextAlignmentCenter;
    [cell addSubview:testLabel];
    
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
         
EventDetailsData *NVC = [self.storyboard instantiateViewControllerWithIdentifier:@"eventDetailsData"];
    NVC.eventSelected = indexPath.row;
    [self presentViewController:NVC animated:YES completion:nil];
    
    ///
    self.eventTypeSelected = [self.hotalsName objectAtIndex:indexPath.row];
     DataBaseClass *dbc = [[DataBaseClass alloc]init];
    [dbc eventTypeSelected:self.eventTypeSelected];
    
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 10.0;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 30.0;
}

//
@end

//imageCollectionView  lableCollectionView
































