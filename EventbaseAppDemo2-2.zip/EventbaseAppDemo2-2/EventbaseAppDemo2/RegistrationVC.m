//
//  RegistrationVC.m
//  EventbaseAppDemo2
//
//  Created by Harsh Bhatnagar on 30/03/17.
//  Copyright © 2017 harshbhatnagariosdeveloper. All rights reserved.
//
#import "PaymantVC.h"
#import "DataBaseClass.h"
#import "RegistrationVC.h"
#import "ProfileVC.h"
@interface RegistrationVC ()
@property (strong, nonatomic) IBOutlet UITextField *firstNametext;
@property (strong, nonatomic) IBOutlet UITextField *lastNametext;
@property (strong, nonatomic) IBOutlet UITextField *mobiletext;
@property (strong, nonatomic) IBOutlet UITextField *emailText;
@property (strong, nonatomic) IBOutlet UITextField *passwordtext;
@property (strong, nonatomic) IBOutlet UITextField *loginusernameText;
@property (strong, nonatomic) IBOutlet UITextField *loginpasswordText;

@end

@implementation RegistrationVC
NSInteger a,num,i;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)homeBtnAction:(UIButton *)sender {
    NSLog(@"homeBtnAction");
}
- (IBAction)SearchBtnAction:(UIButton *)sender {
    NSLog(@"SearchBtnAction");
}
- (IBAction)calBtn:(UIButton *)sender {
    NSLog(@"calBtn");
}

- (IBAction)profileBtn:(UIButton *)sender {
    ProfileVC *NVC = [self.storyboard instantiateViewControllerWithIdentifier:@"profileVC"];
    [self presentViewController:NVC animated:YES completion:nil];
    //#import "ProfileVC.h"
}


- (IBAction)summitBtn:(id)sender
{
    NSLog(@"summitBtn");
    NSInteger a =[_mobiletext.text integerValue];
    NSString *mob = _mobiletext.text;
    NSLog(@"%@",mob);
    
    NSLog(@"%ld",(long)a);
    i=0;
    num=a;
    NSInteger flag = 0;
    NSLog(@"%ld",(long)flag);
    while (!(num==0))
    {
        i++;
        num = a/10;
        a=num;
        NSLog(@"%ld %ld %ld",a,num,i);
    }
    if (!(i==10))
        {
            UIAlertView *new = [[UIAlertView alloc] initWithTitle:@"Invalid Data" message:@"Please Fill Proper Phone number." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [new show];
            flag = 1;
            
        }
    
    
    if (!([self.firstNametext hasText] && [self.lastNametext hasText] && [self.mobiletext hasText] && [self.emailText hasText] && [self.passwordtext hasText]))
      {
        UIAlertView *new = [[UIAlertView alloc] initWithTitle:@"InComplite Data" message:@"Please Fill All Details" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [new show];
      }
      else if (flag==0)
          {
            DataBaseClass *dbc = [[DataBaseClass alloc]init];
            [dbc dataBaseNSUserDefaults:self.firstNametext.text lastName:self.lastNametext.text mobile:self.mobiletext.text email:self.emailText.text password:self.passwordtext.text];

        //PaymantVC
        PaymantVC *NVC = [self.storyboard instantiateViewControllerWithIdentifier:@"paymantVC"];
        [self presentViewController:NVC animated:YES completion:nil];
       }
    else
    {
        NSLog(@"This line is printed because code is running rihgt.");
    }
}

- (IBAction)googleBtn:(id)sender {
    NSLog(@"googleBtn");
}
- (IBAction)facebookBtn:(id)sender {
    NSLog(@"facebookBtn");
}
- (IBAction)loginBtn:(id)sender {
    NSLog(@"loginBtn");
    if (!([self.loginpasswordText hasText] && [self.loginusernameText hasText])) {
        UIAlertView *new = [[UIAlertView alloc] initWithTitle:@"InComplite Data" message:@"Please Fill All Details" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [new show];
    }else{
        NSString *firstName = [[NSUserDefaults standardUserDefaults] objectForKey:@"firstName"];
        NSString *password = [[NSUserDefaults standardUserDefaults] objectForKey:@"password"];
        if ([firstName isEqualToString:self.firstNametext.text] && [password isEqualToString:self.passwordtext.text]){
            PaymantVC *NVC = [self.storyboard instantiateViewControllerWithIdentifier:@"paymantVC"];
            [self presentViewController:NVC animated:YES completion:nil];
        }else{
            UIAlertView *new = [[UIAlertView alloc] initWithTitle:@"User Name Password Mismatch" message:@"Please Register Your Self" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [new show];
        }
    
    
    }
}



@end
