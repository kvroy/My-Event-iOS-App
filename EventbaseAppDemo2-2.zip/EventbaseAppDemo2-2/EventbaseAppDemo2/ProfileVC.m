//
//  ProfileVC.m
//  EventbaseAppDemo2
//
//  Created by Harsh Bhatnagar on 30/03/17.
//  Copyright © 2017 harshbhatnagariosdeveloper. All rights reserved.
//

#import "ProfileVC.h"

@interface ProfileVC ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UIImageView *profileImage;
@property (strong, nonatomic) IBOutlet UIButton *profileImageBtnOutlet;
@property (strong, nonatomic) IBOutlet UILabel *userNameLabel;
@property (strong, nonatomic) IBOutlet UILabel *emailidLable;
@property (strong, nonatomic) IBOutlet UILabel *MobileLable;
@property (strong, nonatomic) IBOutlet UITableView *userDetailsTableView;
@property (nonatomic,strong)NSMutableArray * totalevents;
@property (nonatomic,strong)NSMutableArray * eventOrganiserImage;
@property (nonatomic,strong)NSString * eventDetails;
@end

@implementation ProfileVC
- (IBAction)profileImageBtn:(id)sender {
    [self loadImageProfile];
}

- (void)viewDidLoad {
 
    [super viewDidLoad];
    
    //
    self.userDetailsTableView.delegate = self;
    self.userDetailsTableView.dataSource = self;
    [self.userDetailsTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"SimpleTableItem"];
    [self.view addSubview:self.userDetailsTableView];
     self.totalevents=[NSMutableArray arrayWithObjects:@"Event1",@"Event2",nil];
    
    // Do any additional setup after loading the view.
    NSString *firstname = [[NSUserDefaults standardUserDefaults] objectForKey:@"firstName"];
    NSString *emailID = [[NSUserDefaults standardUserDefaults] objectForKey:@"email"];
    NSString *mobileNo = [[NSUserDefaults standardUserDefaults] objectForKey:@"mobile"];
    self.MobileLable.text = mobileNo;
    self.emailidLable.text = emailID;
    self.userNameLabel.text = firstname;
    self.eventOrganiserImage =[[NSMutableArray alloc]init];
    [self.eventOrganiserImage  addObject:[UIImage imageNamed:@"iec.png"]];
    [self.eventOrganiserImage  addObject:[UIImage imageNamed:@"hotal1.png"]];
    
    self.eventDetails =[[NSMutableArray alloc]init];
    //eventTypeSelected dateOfEvent eventState eventCity placeForEvent
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.totalevents.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"SimpleTableItem";
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:simpleTableIdentifier];
    
    ///////// adject the size
    float height=60.0f*[self.totalevents count];
    
    [self.userDetailsTableView setFrame:CGRectMake(self.userDetailsTableView.frame.origin.x, self.userDetailsTableView.frame.origin.y, self.userDetailsTableView.frame.size.width,(60.0f*([self.totalevents count])))];

     cell.textLabel.text = [self.totalevents objectAtIndex:indexPath.row];
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.detailTextLabel.frame = CGRectMake(10, 20, 200,22);
    cell.detailTextLabel.numberOfLines = 5;
    cell.detailTextLabel.font = [UIFont boldSystemFontOfSize:12];
    [self events];
    cell.detailTextLabel.text= self.eventDetails;
    
    cell.imageView.image = [self.eventOrganiserImage objectAtIndex:indexPath.row];
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    cell.detailTextLabel.font = [UIFont boldSystemFontOfSize:10];
    cell.detailTextLabel.backgroundColor=[UIColor clearColor];
    cell.textLabel.frame = CGRectMake(10, 20, 100,22);
    cell.detailTextLabel.frame = CGRectMake(10, 20, 200,22);
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
        return 100.0;
   }
/////

-(void)loadImageProfile{
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc]init];
    imagePickerController.delegate = self;
    imagePickerController.sourceType =  UIImagePickerControllerSourceTypePhotoLibrary;
    
   
    [self presentViewController:imagePickerController animated:YES completion:nil];
    
}
//#pragma mark - Imagepicker delegate
//- (void)imagePickerController:(UIImagePickerController *)imagePicker didFinishPickingMediaWithInfo:(NSDictionary *)info
//{
   // UIImage *origImage = [info objectForKey:UIImagePickerControllerOriginalImage];
   //  NSLog(@"origImage %@",origImage);
    //Code to save image in local directory
   // NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
   
  //  NSString *documentsDirectory = [paths objectAtIndex:0];
    
//    NSString *savedImagePath = [documentsDirectory stringByAppendingPathComponent:@"savedImage.png"];
//     NSLog(@"savedImagePath %@",savedImagePath);
//     UIImage *img = [UIImage imageWithContentsOfFile:savedImagePath];
//    self.profileImage.image = img; // origImage is my image from photo library
//    NSData *imageData = UIImagePNGRepresentation( self.profileImage.image);
//     NSLog(@"imageData %@",imageData);
//    [imageData writeToFile:savedImagePath atomically:NO];
//    
 //   [imagePicker dismissViewControllerAnimated:YES completion:nil];
 //   self.profileImage.image =image;
//}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image
                  editingInfo:(NSDictionary *)editingInfo
{
    
//     UIImage *origImage = [editingInfo objectForKey:UIImagePickerControllerOriginalImage];
//    NSLog(@"origImage %@",origImage);
//    //Code to save image in local directory
//        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//        NSString *documentsDirectory = [paths objectAtIndex:0];
//        NSString *savedImagePath = [documentsDirectory stringByAppendingPathComponent:@"savedImage.png"];
//        UIImage *img = [UIImage imageWithContentsOfFile:savedImagePath];
//    
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    self.profileImage.image =image;
 }

-(void)events{
//eventTypeSelected dateOfEvent eventState eventCity placeForEvent
    NSString *eventTypeSelected = [[NSUserDefaults standardUserDefaults] objectForKey:@"eventTypeSelected"];
    NSString *dateOfEvent = [[NSUserDefaults standardUserDefaults] objectForKey:@"dateOfEvent"];
    NSString *eventState = [[NSUserDefaults standardUserDefaults] objectForKey:@"eventState"];
    NSString *eventCity = [[NSUserDefaults standardUserDefaults] objectForKey:@"eventCity"];
    NSString *placeForEvent = [[NSUserDefaults standardUserDefaults] objectForKey:@"placeForEvent"];
    
self.eventDetails = [NSString stringWithFormat:@"Event: %@,Date Of Event: %@,State: %@,City: %@,Place Of Event: %@", eventTypeSelected, dateOfEvent, eventState,eventCity,placeForEvent];
    
    NSLog(@"eventDetails %@",self.eventDetails);
}

- (IBAction)editUserDetails:(id)sender {
}
///////





@end
