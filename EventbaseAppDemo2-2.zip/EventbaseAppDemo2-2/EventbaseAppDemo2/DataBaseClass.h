//
//  DataBaseClass.h
//  EventbaseAppDemo2
//
//  Created by Harsh Bhatnagar on 04/04/17.
//  Copyright © 2017 harshbhatnagariosdeveloper. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataBaseClass : NSObject
@property (strong, nonatomic) NSString  *firstName;
@property (strong, nonatomic) NSString  *lastName;
@property (strong, nonatomic) NSString  *mobile;
@property (strong, nonatomic) NSString  *email;
@property (strong, nonatomic) NSString  *password;
@property (strong, nonatomic)NSMutableDictionary *mutableDict;

-(void)dataBaseNSUserDefaults:(NSString *)firstName lastName:(NSString *)lastName mobile:(NSString *)mobile email:(NSString *)email password:(NSString *)password;

///ViewController
@property(nonatomic, retain)NSString* eventTypeSelected;
-(void)eventTypeSelected:(NSString *)eventTypeSelected;

//EventDetailsData
@property(nonatomic , strong)NSString * dateOfEvent;
@property(nonatomic , strong)NSString * eventState;
@property(nonatomic , strong)NSString * eventCity;
@property(nonatomic , strong)NSString * numberOfGuest;
@property(nonatomic , strong)NSString * costPerGuest;
-(void)eventdetailsdata:(NSString *)dateOfEvent eventState:(NSString *)eventState eventCity:(NSString *)eventCity numberOfGuest:(NSString *)numberOfGuest costPerGuest:(NSString *)costPerGuest;



//EventPlaceDetailsVC
@property(nonatomic , strong)NSString * placeForEvent;
-(void)placeForEvent:(NSString *)placeforevent;

//ServicesVC
@property(nonatomic ,strong)NSMutableArray *sirvicesArray;
-(void)sirvicesAry:(NSMutableArray *)sirvicesarray;


//
-(void)paymantVC;
@property(nonatomic , strong)NSString * totalPay;

@end
//firstName lastName mobile email password