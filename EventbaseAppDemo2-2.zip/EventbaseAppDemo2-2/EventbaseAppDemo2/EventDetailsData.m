//
//  EventDetailsData.m
//  EventbaseAppDemo2
//
//  Created by Harsh Bhatnagar on 30/03/17.
//  Copyright © 2017 harshbhatnagariosdeveloper. All rights reserved.
//
#import "ProfileVC.h"
#import "DataBaseClass.h"
#import "EventPlaceDetailsVC.h"
#import "EventDetailsData.h"

@interface EventDetailsData ()<UIPickerViewDataSource,UIPickerViewDelegate>
@property (strong, nonatomic) IBOutlet UIDatePicker *datePikerOutlet;
@property (strong, nonatomic) IBOutlet UILabel *cityLable;
@property (strong, nonatomic) IBOutlet UILabel *dateLable;
@property (strong, nonatomic) IBOutlet UILabel *stateLable;
@property (strong, nonatomic) IBOutlet UIPickerView *pickerEventCity;
@property (strong, nonatomic) IBOutlet UITextField *noGusttext;
@property (strong, nonatomic) IBOutlet UITextField *perGustCostText;
@property (nonatomic,strong)NSMutableArray * cityNameArray;
@property (nonatomic,strong)NSMutableArray * stateNameArray;
@property (nonatomic,strong)NSMutableArray * dateArray;
@property (strong, nonatomic) IBOutlet UIButton *selectDateBtnOutlet;
@property (strong, nonatomic) IBOutlet UIButton *selectStateBtnOutlet;
@property (strong, nonatomic) IBOutlet UIButton *selectCityBtnOutlet;
@property (strong, nonatomic) IBOutlet UIButton *summitBtnOutlet;

@property(nonatomic, retain) NSDate *maximumDate;
@property(nonatomic, retain) NSDate *minimumDate;
@property(nonatomic, retain) NSDate *date;
@end

@implementation EventDetailsData


/// date Picker
- (IBAction)datePickers:(id)sender {
    NSDate *todayDate = [NSDate date];
    [_datePikerOutlet setMinimumDate:todayDate];
 self.dateLable.hidden = NO;
    self.dateLable.text = @"";
    self.datePikerOutlet.datePickerMode = UIDatePickerModeDateAndTime;
    [self.view addSubview:self.datePikerOutlet];
    self.datePikerOutlet.hidden = NO;
    [self.datePikerOutlet addTarget:self
                    action:@selector(dateChange:)forControlEvents:UIControlEventValueChanged];
    NSDateFormatter *formate=[[NSDateFormatter alloc]init];
    [formate setDateFormat:@"dd-MMM-yy hh:mm a "];
    self.dateLable.text=[formate stringFromDate:self.datePikerOutlet.date];
    self.dateOfEvent=[formate stringFromDate:self.datePikerOutlet.date];
    self.selectStateBtnOutlet.hidden=NO;
}
-(void)dateChange:(id)sender
{
    NSLog(@"date is %@",self.datePikerOutlet.date);
    NSDateFormatter *formate=[[NSDateFormatter alloc]init];
    [formate setDateFormat:@"dd-MMM-yy hh:mm a "];
    self.dateLable.text=[formate stringFromDate:self.datePikerOutlet.date];
    self.selectStateBtnOutlet.hidden=NO;
}
////////////// date picker
- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"event op =%ld",(long)self.eventSelected);
    // Do any additional setup after loading the view.
    self.pickerEventCity.delegate = self;
    self.pickerEventCity.dataSource = self;
    self.pickerEventCity.showsSelectionIndicator = YES;
    [self.view addSubview:self.pickerEventCity];
    
    self.stateNameArray = [[NSMutableArray alloc]init];
    self.stateNameArray=[NSMutableArray arrayWithObjects:@"Delhi-Ncr",@"Uttar Pradesh",@"Bihar",@"Himanchal Pradesh",@"Rajsthan",@"Gujrat",nil];
    self.cityNameArray = [[NSMutableArray alloc]init];
    self.cityNameArray=[NSMutableArray arrayWithObjects:@"Lucknow",@"Varanasi",@"Kanpur",@"Gorakhpur",@"Jaunpur",@"Faizabad",nil];

    //default hidden
    self.selectStateBtnOutlet.hidden =YES;
    self.stateLable.hidden=YES;
    self.selectCityBtnOutlet.hidden =YES;
    self.cityLable.hidden=YES;
    self.pickerEventCity.hidden=YES;
    self.dateLable.hidden=YES;
    self.datePikerOutlet.hidden=YES;
    self.noGusttext.hidden=YES;
    self.perGustCostText.hidden=YES;
    self.summitBtnOutlet.hidden=YES;
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)homeBtnAction:(UIButton *)sender {
}
- (IBAction)SearchBtnAction:(UIButton *)sender {
}
- (IBAction)calBtn:(UIButton *)sender {
}

- (IBAction)profileBtn:(UIButton *)sender {
    ProfileVC *NVC = [self.storyboard instantiateViewControllerWithIdentifier:@"profileVC"];
    [self presentViewController:NVC animated:YES completion:nil];
    //#import "ProfileVC.h"
}

- (IBAction)summitBtn:(UIButton *)sender {
   
    if (!([self.perGustCostText hasText] && [self.noGusttext hasText] )) {
        UIAlertView *new = [[UIAlertView alloc] initWithTitle:@"Please Fill All Details" message:@"Please Fill The Number Of Guests Or Costing Per Guests" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [new show];
    }else{
        
        self.numberOfGuest = self.noGusttext.text;
        self.costPerGuest = self.perGustCostText.text;
        self.eventState = self.stateLable.text;
        self.eventCity = self.cityLable.text;
        DataBaseClass *dbc = [[DataBaseClass alloc]init];

        [dbc eventdetailsdata:_numberOfGuest eventState:_eventState eventCity:_eventCity numberOfGuest:_numberOfGuest costPerGuest:self.costPerGuest];
        
EventPlaceDetailsVC *NVC = [self.storyboard instantiateViewControllerWithIdentifier:@"eventPlaceDetailsVC"];
       // NVC.eventSelected = indexPath.row;
        [self presentViewController:NVC animated:YES completion:nil];
    }
}

- (IBAction)selectDateBtn:(id)sender {
    self.datePikerOutlet.hidden=NO;
    
}
- (IBAction)selectStateBtn:(id)sender {
    self.selectStateBtnOutlet.tag =11;
    self.selectCityBtnOutlet.tag =2;
    self.datePikerOutlet.hidden=YES;
    self.pickerEventCity.hidden=NO;
    self.pickerEventCity.reloadAllComponents;

}
- (IBAction)selectCityBtn:(id)sender {
    self.selectStateBtnOutlet.tag =1;
    self.selectCityBtnOutlet.tag =22;
    self.pickerEventCity.reloadAllComponents;
}


////Picker
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
        return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
  if (self.selectStateBtnOutlet.tag==11){
        return [self.stateNameArray count];
    }else if (self.selectCityBtnOutlet.tag==22){
         return [self.cityNameArray count];
    }else {
        return 1;
    }
    
}
#pragma mark- Picker View Delegate


-(void)pickerView:(UIPickerView *)pickerView didSelectRow: (NSInteger)row inComponent:(NSInteger)component{
    if (self.selectStateBtnOutlet.tag==11){
        
        self.stateLable.hidden=NO;
        self.stateLable.text = [self.stateNameArray objectAtIndex:row];
        self.selectCityBtnOutlet.hidden = NO;
        
    }else if (self.selectCityBtnOutlet.tag==22){
        
    self.cityLable.hidden=NO;
    self.cityLable.text = [self.cityNameArray objectAtIndex:row];
        self.perGustCostText.hidden=NO;
        self.noGusttext.hidden=NO;
        self.summitBtnOutlet.hidden=NO;
        
    }
    
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow: (NSInteger)row forComponent:(NSInteger)component{
  if(self.selectStateBtnOutlet.tag==11){
     return [self.stateNameArray objectAtIndex:row];
 }else if (self.selectCityBtnOutlet.tag==22){
 return [self.cityNameArray objectAtIndex:row];
 }else {
     return @"Empty";
 }
   
    
}
















@end
