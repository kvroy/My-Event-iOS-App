#import "statesBaseClass.h"

@implementation statesBaseClass

@synthesize name;
@synthesize statesBaseClassId;

- (void)dealloc {

    [name release], name = nil;
    [statesBaseClassId release], statesBaseClassId = nil;

    [super dealloc];

}

+ (statesBaseClass *)instanceFromDictionary:(NSDictionary *)aDictionary {

    statesBaseClass *instance = [[[statesBaseClass alloc] init] autorelease];
    [instance setAttributesFromDictionary:aDictionary];
    return instance;

}

- (void)setAttributesFromDictionary:(NSDictionary *)aDictionary {

    if (![aDictionary isKindOfClass:[NSDictionary class]]) {
        return;
    }

    [self setValuesForKeysWithDictionary:aDictionary];

}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {

    if ([key isEqualToString:@"id"]) {
        [self setValue:value forKey:@"statesBaseClassId"];
    } else {
        [super setValue:value forUndefinedKey:key];
    }

}



@end
